-- -----------------------------
-- Yii MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2016-01-21 03:32:37
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `le_action`
-- -----------------------------
DROP TABLE IF EXISTS `le_action`;
CREATE TABLE `le_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `le_action`
-- -----------------------------
INSERT INTO `le_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|username]在[time|time_format]登录了后台', '1', '1', '1453273677');
INSERT INTO `le_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `le_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `le_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|username]在[time|time_format]发表了一篇文章。
表[model]，记录编号[record]。', '2', '1', '1386139726');
INSERT INTO `le_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '1', '1383285551');
INSERT INTO `le_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `le_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `le_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `le_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `le_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `le_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `le_action` VALUES ('12', 'test_biaozhi', '测试', '【aa】', 'ffffffffffff', 'ddd', '1', '-1', '1451442131');

-- -----------------------------
-- Table structure for `le_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `le_action_log`;
CREATE TABLE `le_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `le_action_log`
-- -----------------------------
INSERT INTO `le_action_log` VALUES ('186', '1', '1', '0', 'loginForm', '1', '在2016-01-02 05:04登录了后台', '1', '1451707441');
INSERT INTO `le_action_log` VALUES ('187', '1', '1', '0', 'loginForm', '1', '在2016-01-02 12:20登录了后台', '1', '1451733657');
INSERT INTO `le_action_log` VALUES ('188', '1', '35', '0', 'loginForm', '35', '在2016-01-02 13:47登录了后台', '1', '1451738870');
INSERT INTO `le_action_log` VALUES ('189', '1', '1', '0', 'loginForm', '1', '在2016-01-04 03:19登录了后台', '1', '1451873997');
INSERT INTO `le_action_log` VALUES ('190', '1', '1', '0', 'loginForm', '1', '在2016-01-05 02:20登录了后台', '1', '1451956827');
INSERT INTO `le_action_log` VALUES ('191', '1', '1', '0', 'loginForm', '1', '在2016-01-05 02:20登录了后台', '1', '1451956839');
INSERT INTO `le_action_log` VALUES ('192', '1', '56', '0', 'loginForm', '56', 'admin在2016-01-05 07:27登录了后台', '1', '1451975225');
INSERT INTO `le_action_log` VALUES ('193', '1', '1', '0', 'loginForm', '1', '在2016-01-07 15:00登录了后台', '1', '1452175236');
INSERT INTO `le_action_log` VALUES ('194', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-07 15:14登录了后台', '1', '1452176051');
INSERT INTO `le_action_log` VALUES ('195', '1', '1', '0', 'loginForm', '1', '在2016-01-07 15:34登录了后台', '1', '1452177282');
INSERT INTO `le_action_log` VALUES ('196', '1', '1', '0', 'loginForm', '1', '在2016-01-08 03:56登录了后台', '1', '1452221812');
INSERT INTO `le_action_log` VALUES ('197', '1', '1', '0', 'loginForm', '1', '在2016-01-09 06:30登录了后台', '1', '1452317449');
INSERT INTO `le_action_log` VALUES ('198', '1', '1', '0', 'loginForm', '1', '在2016-01-11 07:04登录了后台', '1', '1452492245');
INSERT INTO `le_action_log` VALUES ('199', '1', '1', '0', 'loginForm', '1', '在2016-01-12 02:19登录了后台', '1', '1452561583');
INSERT INTO `le_action_log` VALUES ('200', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-12 09:47登录了后台', '1', '1452588426');
INSERT INTO `le_action_log` VALUES ('201', '1', '1', '0', 'loginForm', '1', '在2016-01-13 02:33登录了后台', '1', '1452648837');
INSERT INTO `le_action_log` VALUES ('202', '1', '1', '0', 'loginForm', '1', '在2016-01-13 15:20登录了后台', '1', '1452694859');
INSERT INTO `le_action_log` VALUES ('203', '1', '1', '0', 'loginForm', '1', '在2016-01-14 02:21登录了后台', '1', '1452734480');
INSERT INTO `le_action_log` VALUES ('204', '1', '1', '0', 'loginForm', '1', '在2016-01-15 02:15登录了后台', '1', '1452820541');
INSERT INTO `le_action_log` VALUES ('205', '1', '1', '0', 'loginForm', '1', '在2016-01-16 03:46登录了后台', '1', '1452912415');
INSERT INTO `le_action_log` VALUES ('206', '1', '1', '0', 'loginForm', '1', '在2016-01-16 06:42登录了后台', '1', '1452922955');
INSERT INTO `le_action_log` VALUES ('207', '1', '35', '0', 'loginForm', '35', '在2016-01-16 07:53登录了后台', '1', '1452927195');
INSERT INTO `le_action_log` VALUES ('208', '1', '1', '0', 'loginForm', '1', '在2016-01-16 07:55登录了后台', '1', '1452927324');
INSERT INTO `le_action_log` VALUES ('209', '1', '1', '0', 'loginForm', '1', '在2016-01-18 10:10登录了后台', '1', '1453108242');
INSERT INTO `le_action_log` VALUES ('210', '1', '1', '0', 'loginForm', '1', '在2016-01-19 02:54登录了后台', '1', '1453168473');
INSERT INTO `le_action_log` VALUES ('211', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-19 08:35登录了后台', '1', '1453188942');
INSERT INTO `le_action_log` VALUES ('212', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-19 08:54登录了后台', '1', '1453190077');
INSERT INTO `le_action_log` VALUES ('213', '1', '1', '0', 'loginForm', '1', '在2016-01-20 04:10登录了后台', '1', '1453259420');
INSERT INTO `le_action_log` VALUES ('214', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-20 07:15登录了后台', '1', '1453270501');
INSERT INTO `le_action_log` VALUES ('215', '1', '1', '0', 'loginForm', '1', '在2016-01-20 07:27登录了后台', '1', '1453271268');
INSERT INTO `le_action_log` VALUES ('216', '1', '1', '0', 'loginForm', '1', '在2016-01-20 07:33登录了后台', '1', '1453271632');
INSERT INTO `le_action_log` VALUES ('217', '1', '1', '0', 'loginForm', '1', 'admin在2016-01-20 10:09登录了后台', '1', '1453280995');
INSERT INTO `le_action_log` VALUES ('218', '1', '1', '0', 'loginForm', '1', '在2016-01-21 03:32登录了后台', '1', '1453343543');

-- -----------------------------
-- Table structure for `le_addons`
-- -----------------------------
DROP TABLE IF EXISTS `le_addons`;
CREATE TABLE `le_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `le_addons`
-- -----------------------------
INSERT INTO `le_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{"title":"\u7cfb\u7edf\u4fe1\u606f","width":"1","display":"1","status":"0"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `le_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{"title":"OneThink\u5f00\u53d1\u56e2\u961f","width":"2","display":"1"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `le_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{"title":"\u7cfb\u7edf\u4fe1\u606f","width":"2","display":"1"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `le_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{"editor_type":"2","editor_wysiwyg":"1","editor_height":"300px","editor_resize_type":"1"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `le_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `le_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{"comment_type":"1","comment_uid_youyan":"","comment_short_name_duoshuo":"","comment_data_list_duoshuo":""}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `le_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{"editor_type":"2","editor_wysiwyg":"1","editor_height":"500px","editor_resize_type":"1"}', 'thinkphp', '0.1', '1383126253', '0');

-- -----------------------------
-- Table structure for `le_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `le_attachment`;
CREATE TABLE `le_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `le_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `le_attribute`;
CREATE TABLE `le_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `le_attribute`
-- -----------------------------
INSERT INTO `le_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录
2:主题
3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐
2:频道页推荐
4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见
1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `le_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `le_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `le_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除
0:禁用
1:正常
2:待审核
3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html
1:ubb
2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html
1:ubb
2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `le_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `le_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `le_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `le_auth_extend`;
CREATE TABLE `le_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `le_auth_extend`
-- -----------------------------
INSERT INTO `le_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `le_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `le_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `le_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `le_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `le_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `le_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `le_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `le_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `le_auth_group`;
CREATE TABLE `le_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_auth_group`
-- -----------------------------
INSERT INTO `le_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `le_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户
', '1', '1,2,3,5,15,16,18,19,20,21,22,23,24,25,26,27,61,62,63,64,65,66,67,68,69,70,71,72,73,74,80,81,82,83,84,86,87,88,89,90,91,92,93,100,102,103,107,108,109,110,195,218');
INSERT INTO `le_auth_group` VALUES ('5', 'admin', '1', 'ffff', 'este', '-1', '');
INSERT INTO `le_auth_group` VALUES ('6', 'admin', '1', 'ff', 'ff', '-1', '');

-- -----------------------------
-- Table structure for `le_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `le_auth_group_access`;
CREATE TABLE `le_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_auth_group_access`
-- -----------------------------
INSERT INTO `le_auth_group_access` VALUES ('36', '1');
INSERT INTO `le_auth_group_access` VALUES ('35', '2');

-- -----------------------------
-- Table structure for `le_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `le_auth_rule`;
CREATE TABLE `le_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_auth_rule`
-- -----------------------------
INSERT INTO `le_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `le_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '1', '');
INSERT INTO `le_auth_rule` VALUES ('3', 'admin', '2', 'Admin/Users/index', '用户', '1', '');
INSERT INTO `le_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `le_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `le_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `le_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `le_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `le_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `le_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `le_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `le_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `le_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `le_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `le_auth_rule` VALUES ('19', 'admin', '1', 'Admin/Users/addaction', '新增用户行为', '1', '');
INSERT INTO `le_auth_rule` VALUES ('20', 'admin', '1', 'Admin/Users/editaction', '编辑用户行为', '1', '');
INSERT INTO `le_auth_rule` VALUES ('21', 'admin', '1', 'Admin/Users/saveAction', '保存用户行为', '1', '');
INSERT INTO `le_auth_rule` VALUES ('22', 'admin', '1', 'Admin/Users/setStatus', '变更行为状态', '1', '');
INSERT INTO `le_auth_rule` VALUES ('23', 'admin', '1', 'Admin/Users/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `le_auth_rule` VALUES ('24', 'admin', '1', 'Admin/Users/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `le_auth_rule` VALUES ('25', 'admin', '1', 'Admin/Users/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `le_auth_rule` VALUES ('26', 'admin', '1', 'Admin/Users/index', '用户信息', '1', '');
INSERT INTO `le_auth_rule` VALUES ('27', 'admin', '1', 'Admin/Users/action', '用户行为', '1', '');
INSERT INTO `le_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `le_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `le_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `le_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `le_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `le_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `le_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `le_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `le_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `le_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `le_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `le_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `le_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `le_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `le_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `le_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `le_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `le_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `le_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `le_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `le_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `le_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `le_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `le_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `le_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `le_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `le_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `le_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `le_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `le_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `le_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `le_auth_rule` VALUES ('88', 'admin', '1', 'Admin/Users/add', '新增用户', '1', '');
INSERT INTO `le_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `le_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `le_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `le_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `le_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `le_auth_rule` VALUES ('108', 'admin', '1', 'Admin/Users/updatePassword', '修改密码', '1', '');
INSERT INTO `le_auth_rule` VALUES ('109', 'admin', '1', 'Admin/Users/updateNickname', '修改昵称', '1', '');
INSERT INTO `le_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `le_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('124', 'admin', '2', 'Admin/Users/add', '新增用户', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('125', 'admin', '2', 'Admin/Users/action', '用户行为', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('126', 'admin', '2', 'Admin/Users/addAction', '新增用户行为', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('127', 'admin', '2', 'Admin/Users/editAction', '编辑用户行为', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('128', 'admin', '2', 'Admin/Users/saveAction', '保存用户行为', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('129', 'admin', '2', 'Admin/Users/setStatus', '变更行为状态', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('130', 'admin', '2', 'Admin/Users/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('131', 'admin', '2', 'Admin/Users/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('132', 'admin', '2', 'Admin/Users/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `le_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('202', 'admin', '2', 'Admin/Users/updatePassword', '修改密码', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('203', 'admin', '2', 'Admin/Users/updateNickname', '修改昵称', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `le_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `le_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `le_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `le_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `le_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `le_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `le_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `le_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `le_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `le_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `le_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `le_auth_rule` VALUES ('217', 'admin', '1', 'Admin/Email/index', '邮件发送', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('218', 'admin', '1', 'Admin/users/chat', '即时通讯', '1', '');
INSERT INTO `le_auth_rule` VALUES ('219', 'admin', '1', 'Admin/users/mail', '邮件内容', '1', '');
INSERT INTO `le_auth_rule` VALUES ('220', 'admin', '1', 'Admin/users/sendemail', '邮件发送', '1', '');
INSERT INTO `le_auth_rule` VALUES ('221', 'admin', '1', 'Admin/users/emailedit', '邮件编辑', '1', '');
INSERT INTO `le_auth_rule` VALUES ('222', 'admin', '1', 'Admin/users/emaildel', '删除邮件', '1', '');
INSERT INTO `le_auth_rule` VALUES ('223', 'admin', '1', 'Admin/#', '图片管理', '-1', '');
INSERT INTO `le_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Picture/index', '图片管理', '1', '');
INSERT INTO `le_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Picture/add', '图片添加', '1', '');
INSERT INTO `le_auth_rule` VALUES ('226', 'admin', '1', 'Admin/Picture/edit', '图片类型修改', '1', '');
INSERT INTO `le_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Picture/sort', '图片类型排序', '1', '');

-- -----------------------------
-- Table structure for `le_category`
-- -----------------------------
DROP TABLE IF EXISTS `le_category`;
CREATE TABLE `le_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `marks` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `le_category`
-- -----------------------------
INSERT INTO `le_category` VALUES ('1', 'blog', '解惑消息', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1443713309', '1', '0', '0');
INSERT INTO `le_category` VALUES ('2', 'default_blog', '文艺天地', '1', '1', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '0', '1', '1', '', '1450755239', '1450775398', '1', '0', '31');
INSERT INTO `le_category` VALUES ('41', 'code', '技术天地', '1', '0', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '1', '0', '', '', '1443713343', '1451895012', '1', '0', '0');
INSERT INTO `le_category` VALUES ('42', 'email', '邮件管理', '1', '0', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '1', '0', '', '', '1444463705', '1444463862', '1', '0', '0');
INSERT INTO `le_category` VALUES ('45', 'testt', 'testt', '2', '0', '10', '', '', '', '', '', '', '', '', '1', '0', '1', '1', '0', '0', '', '', '1450762781', '1450762781', '1', '1', '0');

-- -----------------------------
-- Table structure for `le_channel`
-- -----------------------------
DROP TABLE IF EXISTS `le_channel`;
CREATE TABLE `le_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '状态：0启用，1禁用',
  `marks` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '删除标志',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_channel`
-- -----------------------------
INSERT INTO `le_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1451895034', '1', '0', '0');
INSERT INTO `le_channel` VALUES ('2', '0', '文艺天地', 'Article/index?category=default_blog', '3', '1379475131', '1443753970', '1', '0', '0');
INSERT INTO `le_channel` VALUES ('3', '0', '官网', 'http://www.onethink.cn', '5', '1379475154', '1450148677', '0', '0', '0');
INSERT INTO `le_channel` VALUES ('4', '0', '技术天地', 'Article/index?category=code', '2', '1443713188', '1443713188', '1', '0', '0');
INSERT INTO `le_channel` VALUES ('5', '0', '我要发布', 'Article/publish', '4', '1444025295', '1444701775', '1', '0', '0');
INSERT INTO `le_channel` VALUES ('6', '5', '发布', '/Article/add', '0', '1444712573', '1444712737', '1', '0', '0');
INSERT INTO `le_channel` VALUES ('7', '0', 'test', '#', '0', '1450148954', '1450148954', '1', '1', '0');
INSERT INTO `le_channel` VALUES ('8', '0', 'ttt', '#', '0', '1450148967', '1450148967', '1', '1', '0');

-- -----------------------------
-- Table structure for `le_config`
-- -----------------------------
DROP TABLE IF EXISTS `le_config`;
CREATE TABLE `le_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_config`
-- -----------------------------
INSERT INTO `le_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '0', '', '网站标题前台显示标题', '1378898976', '1451895063', '1', '解惑网', '2');
INSERT INTO `le_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '解惑网 编程初学者的乐园，帮助初学者和即将学习编程的同学提升兴趣，帮助已经入门的同学继续深入学习', '5');
INSERT INTO `le_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'html,css，javascript，php', '8');
INSERT INTO `le_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '9');
INSERT INTO `le_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字
1:字符
2:文本
3:数组
4:枚举', '10');
INSERT INTO `le_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `le_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐
2:频道页推荐
4:网站首页推荐', '4');
INSERT INTO `le_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见
1:仅注册会员可见
2:仅管理员可见', '10');
INSERT INTO `le_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认
blue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'blue_color', '10');
INSERT INTO `le_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本
2:内容
3:用户
4:系统', '9');
INSERT INTO `le_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图
2:控制器', '9');
INSERT INTO `le_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1
AUTH_TYPE:2', '8');
INSERT INTO `le_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能
1:开启草稿功能
', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '7');
INSERT INTO `le_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '1');
INSERT INTO `le_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `le_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册
1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '6');
INSERT INTO `le_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day
3024-night:3024 night
ambiance:ambiance
base16-dark:base16 dark
base16-light:base16 light
blackboard:blackboard
cobalt:cobalt
eclipse:eclipse
elegant:elegant
erlang-dark:erlang-dark
lesser-dark:lesser-dark
midnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '10');
INSERT INTO `le_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', '../../Data', '8');
INSERT INTO `le_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '9');
INSERT INTO `le_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩
1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `le_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通
4:一般
9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `le_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭
1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `le_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox
1:article/mydocument
2:Category/tree
3:Index/verify
4:file/upload
5:file/download
6:user/updatePassword
7:user/updateNickname
8:user/submitPassword
9:user/submitNickname
10:file/uploadpicture', '3');
INSERT INTO `le_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook
1:Addons/edithook
2:Addons/delhook
3:Addons/updateHook
4:Admin/getMenus
5:Admin/recordList
6:AuthManager/updateRules
7:AuthManager/tree', '10');
INSERT INTO `le_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '11', '10');
INSERT INTO `le_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `le_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭
1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '8');
INSERT INTO `le_config` VALUES ('41', 'test', '0', 'test', '0', 'test', 'test', '1449815784', '1449815784', '0', 'test', '2');
INSERT INTO `le_config` VALUES ('42', 'test1', '0', 'test1', '0', 'test', 'tes', '1449823298', '1449823298', '0', '1', '1');
INSERT INTO `le_config` VALUES ('43', 'fdas', '0', 'fdas', '0', 'fdsa', 'fds', '1450063348', '1450063348', '0', 'dfsa', '1');
INSERT INTO `le_config` VALUES ('44', 'testa', '0', 'testtt', '0', 'fff', 'ff', '1450063674', '1450063674', '0', 'fff', '1');
INSERT INTO `le_config` VALUES ('45', 'DOCUMENT_MODEL_TYPE', '0', '文档类型', '2', '', '', '1450405878', '1450405908', '1', '1:目录
2:主题
3:段落', '9');

-- -----------------------------
-- Table structure for `le_document`
-- -----------------------------
DROP TABLE IF EXISTS `le_document`;
CREATE TABLE `le_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型2文学，0技术',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态（-1-删除，0-禁用，1-正常，2-待审核）',
  `mark` tinyint(2) DEFAULT '0' COMMENT '删除标识0未删除，1已删除',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `le_document`
-- -----------------------------
INSERT INTO `le_document` VALUES ('64', '35', '', '泰国', '2', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1445327591', '1445569921', '1', '0');
INSERT INTO `le_document` VALUES ('69', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '11', '1', '0', '0', '0', '0', '0', '1', '1445569920', '1446726183', '1', '0');
INSERT INTO `le_document` VALUES ('70', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '2', '1445569969', '1445569969', '1', '0');
INSERT INTO `le_document` VALUES ('71', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '3', '1445569986', '1445569986', '1', '0');
INSERT INTO `le_document` VALUES ('73', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1453273239', '1453273239', '1', '0');
INSERT INTO `le_document` VALUES ('74', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '4', '1445569993', '1445569993', '1', '0');
INSERT INTO `le_document` VALUES ('75', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1445569993', '1445570031', '1', '0');
INSERT INTO `le_document` VALUES ('76', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1452175321', '1452175321', '-1', '0');
INSERT INTO `le_document` VALUES ('77', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '1452175298', '1452175298', '-1', '0');
INSERT INTO `le_document` VALUES ('78', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '5', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('79', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '6', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('80', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '7', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('81', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '8', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('82', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '9', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('83', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '10', '1445570006', '1445570006', '1', '0');
INSERT INTO `le_document` VALUES ('84', '1', '', '最懂的人，才是最暖的伴', '2', '一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。', '0', '0', '2', '2', '0', '0', '9', '1', '0', '0', '6', '0', '0', '11', '1445569980', '1446169871', '2', '0');
INSERT INTO `le_document` VALUES ('85', '1', '', '提升网站性能开发的10个技巧', '41', '随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。文中为大家总结10条有关性能提升的经验', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '9', '1445996956', '1445996956', '1', '0');
INSERT INTO `le_document` VALUES ('86', '1', '', '红帽加入 Node.js 基金会白金会员', '41', 'node.js在短短的几年间发展如此迅速，掌握它就意味着掌握了web开发的未来！', '0', '0', '2', '2', '0', '0', '12', '1', '0', '0', '0', '0', '0', '2', '1445997060', '1446779031', '1', '0');
INSERT INTO `le_document` VALUES ('88', '1', '', '提升网站性能开发的10个技巧', '41', '随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。文中为大家总结10条有关性能提升的经验', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '8', '1446779013', '1446779013', '1', '0');
INSERT INTO `le_document` VALUES ('91', '1', '', '提升网站性能开发的10个技巧', '41', '随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。文中为大家总结10条有关性能提升的经验', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '12', '0', '0', '1', '1446779019', '1446779019', '1', '0');
INSERT INTO `le_document` VALUES ('92', '1', '', '提升网站性能开发的10个技巧', '41', '随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。文中为大家总结10条有关性能提升的经验', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '3', '1446779019', '1446779019', '1', '0');
INSERT INTO `le_document` VALUES ('93', '1', '', '传智播客最新课程——大前端-HTML5-全栈时代开启谁决沉浮？', '41', '课程介绍： 大前端时代IT技术发展方向是怎样的呢？HTML5时代给开发人员带来怎样的挑战和机遇呢？全栈时代给前端开发工程师带来怎样的革命呢？后端开发工程师在全栈时代如何把握自己的技术人生呢... 开课时间：2015年10月13日20点​', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '4', '1446779019', '1446779019', '-1', '0');
INSERT INTO `le_document` VALUES ('94', '1', '', '传智播客最新课程——大前端-HTML5-全栈时代开启谁决沉浮？', '41', '课程介绍： 大前端时代IT技术发展方向是怎样的呢？HTML5时代给开发人员带来怎样的挑战和机遇呢？全栈时代给前端开发工程师带来怎样的革命呢？后端开发工程师在全栈时代如何把握自己的技术人生呢... 开课时间：2015年10月13日20点​', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '5', '1446779019', '1446779019', '-1', '0');
INSERT INTO `le_document` VALUES ('95', '1', '', '红帽加入 Node.js 基金会白金会员', '41', 'node.js在短短的几年间发展如此迅速，掌握它就意味着掌握了web开发的未来！', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '6', '1446779019', '1446779019', '1', '0');
INSERT INTO `le_document` VALUES ('96', '1', '', '红帽加入 Node.js 基金会白金会员', '41', 'node.js在短短的几年间发展如此迅速，掌握它就意味着掌握了web开发的未来！', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '0', '0', '0', '7', '1446779019', '1446779019', '1', '0');

-- -----------------------------
-- Table structure for `le_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `le_document_article`;
CREATE TABLE `le_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `le_document_article`
-- -----------------------------
INSERT INTO `le_document_article` VALUES ('64', '0', '摩羯
            ', '', '0');
INSERT INTO `le_document_article` VALUES ('69', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" /> 
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('70', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('71', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('73', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">3、人与人之间，总有邂逅；心与心之间，总会生情。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">6、有时候，生活只能是后知后觉，但却必须勇往直前。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">7、人生短短数十载，最要紧的是满足自己，不是讨好他人。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">19、走正确的路，放无心的手，结有道之朋，断无义之友，</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）</p><p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;"><img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" data-ke-src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;"> </p><div><br> </div>', '', '0');
INSERT INTO `le_document_article` VALUES ('74', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('75', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('76', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('77', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('78', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('79', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('80', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('81', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('82', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('83', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" />
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('84', '0', '<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	1、所有的负担都将变成礼物，所受的苦都能照亮未来迷茫的路。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	2、饮清净之茶，戒色花之酒，开方便之门，闭是非之口。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	3、人与人之间，总有邂逅；心与心之间，总会生情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	4、大喜大悲看清自己，大起大落看清朋友。没有一个足够宽容的心，就看不到一个春光明媚的世界。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	5、只要，说出的话，有人愿意听，就是温暖；只要，心里的事，有人愿意懂，就是真情。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	6、有时候，生活只能是后知后觉，但却必须勇往直前。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	7、人生短短数十载，最要紧的是满足自己，不是讨好他人。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	8、人再完美，精神也需要知音，心再坚强。情感也需要慰藉；若有人能陪。就是莫大的满足；若有心能明，便是最好的心语倾诉。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	9、恋爱像是地震，不可预测，有点吓人，可一旦他们安全度过，又会觉得自己竟是那么地幸运。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	10、誓言再美，也比不上一颗融入生命的心；承诺再多，也比不了一直心疼你的人。友情，无需多言，人生路途中风雨如伞；爱情，无需轰烈，平平淡淡中相依相伴。很多时候，有一份懂得，便会温暖心怀；有一份聆听，便会驱走烦恼；生活中，有爱的陪伴，即使苦累心也甜。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	11、使人有面前之誉，不若使人无背后之毁；使人有乍交之欢，不若使人无久处之厌。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	12、如果一个人喜欢安稳的生活，那么你不要试图鼓励她去冒险，相反如果一个人就是喜欢冒险，你也不要诟病她的不切实际。人和人之间的差异就是这样，没有优劣之分，只有本性之别。到最后我们都会发现，穷尽一生，我们都不过是为了满足自己的本性，想要按照自己的本性生活而已。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	13、一辈子并不长，下辈子未必会遇见，请好好把握和珍惜你现在身边的人。错过了也许这辈子就是永远的遗憾了。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	14、人之相处在于真，情之相守在于心。情是一天一天换回来的，心是一点一点处出来的。人生也是一页一页真实的翻过来的。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	15、一种感情，无关年龄，只与倾心有染；一种思念，无关距离，却可以海枯石烂。感情，没有模板，只要感到心暖；相处，没有形式，全凭轻松自然。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	16、愿你贪吃不胖，愿你懒惰不丑，愿你深情不被辜负。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	17、缘不贵多，心诚则行；情不论久，心惜则浓。真心对一个人好，无所谓有所回报；默默付出一份情，只在乎重不重要。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	18、所谓幸福，就是有一颗感恩的心，一个健康的身体，一份称心的工作，一位深爱你的爱人，一帮值得信赖的朋友。
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	19、走正确的路，放无心的手，结有道之朋，断无义之友，
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	20、最深的爱，总是风雨兼程；最浓的情，总是冷暖与共；最懂的人，才是最暖的伴。（爱唯美21wim.com）
</p>
<p style="color:#444444;font-family:'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:15px;">
	<img src="http://p3.wmpic.me/article/2015/06/26/1435293644_MXxSxowG.jpeg" alt="" style="height:auto;" /> 
</p>
<div>
	<br />
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('85', '0', '<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。假如你的网站不能做到快速响应，又或你的App存在延迟，用户很快就会移情你的竞争对手。以下为大家总结10条有关性能提升的经验，以供参考：
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;text-align:center;background-color:#FFFFFF;">
	<img src="http://img.ptcms.csdn.net/article/201510/20/5625dfd8a2058.jpg" style="height:405px;width:512px;" />
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>1.&nbsp;&nbsp;采用反向代理服务器(Reverse Proxy Server)来对应用进行加速和保护</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	其作用主要在以下三方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		负载平衡&nbsp;– 运行在反向代理服务器上的负载平衡器会在不同的不服务器&nbsp; 间进行传输平衡。透过它，你可以进行无差别的服务器增添。
	</li>
	<li>
		存静态文件&nbsp;– 对于直接的文件请求，例如图片文件或代码文件，可以直接存储在反向代理服务器然后直接发送给用户，从而可以进行快速访问并为应用服务器进行减负使得程序性能得到提升。
	</li>
	<li>
		安全保护&nbsp;– 反向代理服务器可以进行高安全度配置和对威胁进行识别和监测。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>2.&nbsp;&nbsp;增添一个负载平衡器</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	为网站增添一个负载平衡器是一个相对简单的变更，但是它可以带来不错的性能和安全性提升。负载平衡器的作用在于在不同服务器间进行传输分发。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	负载平衡器的实施前提是有一个反向代理服务器，它在接收到Internet通信后把相关请求发送到其它服务器。平衡器的妙处在于它支持两个或以上的应用服务器，使用选择算法来分割服务器间的请求。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>3.&nbsp;&nbsp;缓存静态和动态内容</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	缓存技术的使用可使内容更快地展示给用户，其处理策略有：在需求发出时更快地处理内容，把内容存放在更快的设备上，或是使内容离用户更近。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>4.&nbsp;&nbsp;数据压缩</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	压缩技术是一个巨大的潜在性能加速器。其主要作用体现在对图片，视频或音频等文件，能够进行高效的压缩处理。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>5.&nbsp;&nbsp;优化SSL/TLS访问</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	尽管SSL/TLS变得越来越流行，但是它对于性能的影响也应得到重视。其对性能的影响主要体现在两个方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		每当新的连接开启，初始化握手都是无法避免的，即浏览器每次都需要使用HTTP/1.X建立服务器连接。
	</li>
	<li>
		存放于服务器上的加密数据会越来越大，加密后用户读取时也需要进行解码。
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">那么该如何进行处理呢？</span><br />
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		会话缓存—使用ssl_session_cache来直接缓存建立新SSL/TLS连接的参数
	</li>
	<li>
		会话ID化—把指定SSL/TLS的标识/ID存放起来，但要建立新连接时，就可以直接取用，从而免去重新建立通信的繁琐。
	</li>
	<li>
		OCSP stapling优化—通过抓取SSL/TLS认证信息来减免建立通信的时间。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>6.&nbsp;&nbsp;部署HTTP/2或SPDY</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	对于已经启用SSL/TLS的网站，一旦结合HTTP/2和SPDY将能实现性能上的强强联合；因为其结果是会让单一连接的建立仅需一次通信握手。SPDY和HTTP/2的主要特性是它们使用的是单一连接而不是多方连接。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>7.&nbsp;&nbsp;定期更新软件版本</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>8.&nbsp;&nbsp;优化Linux性能</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如对Linux进行以下配置或处理：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Backlog队列
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	如果你有一些将要停用的连接，可以考虑增加net.core.somaxconn。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		文件描述符
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	NGINX允许每个连接最多使用两个文件描述符。如果你的系统服务的是多个连接，你可能需要考虑增大sys.fs.file_max的值。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		瞬时端口
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	当作为一个代理使用时，NGINX会为每个upstream服务器创建临时的瞬时(ephemeral)端口。因此可以尝试加大net.ipv4.ip_local_port_range的值来增加可用端口数。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>9.&nbsp;&nbsp;优化Web服务器性能</b>
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		访问日志优化
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	在NGINX中，在access_log中加入buffer=size参数来实现日志的缓存写入；加入flush=time则可实现在某个时间间隔后进行缓存内容写入。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		缓存
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	启用缓存可使连接响应更快。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		客户端活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	活动连接可减少重连的次数，特别是启用SSL/TLS的情况下。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Upstream活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Upstream连接指的是连接到程序服务器，数据库服务器等的连接。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		限制资源的访问
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	采取合适的策略来限制资源访问可以提高性能和安全性。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行worker处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Worker处理模式就是请求驱动处理模式。NGINX使用了一个基于事件的模型和OS依赖机制来有效地对请求进行分发。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行socket分表
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Socket分表可以为每个worker处理创建一个socket监听器,当核心委派连接分到给监听器时，可以马上知道哪个处理是即将执行的，从而使处理流程变得简洁。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		线程池处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	任何计算机线程都有可能由于单个缓慢的操作而挂起。对于web服务器软件来说，磁盘访问是一个性能瓶颈，例如进行数据复制等操作。当使用线程池来处理时，可以把一些响应慢的操作单独地放入某个任务组里面，从而不会对其它操作造成影响。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>10.进行实时监控以快速解决问题和瓶颈</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	实施实时监控，可以全面掌握系统的运行情况，发现问题解决问题，甚至是找出造成性能瓶颈或运行缓慢的原因。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如可对如下的问题进行监控：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		服务器宕机
	</li>
	<li>
		连接访问丢失
	</li>
	<li>
		服务器缓存丢失严重
	</li>
	<li>
		服务器发送了错误的数据
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">原文来自：</span><a href="https://www.nginx.com/blog/10-tips-for-10x-application-performance/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" target="_blank">Nginx</a>', '', '0');
INSERT INTO `le_document_article` VALUES ('86', '0', '<div id="OSChina_News_66965" class="Body NewsContent TextContent" style="color:#333333;margin:10px 0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<p>
		红帽（Red Hat）公司近日<a target="_blank" href="https://nodejs.org/en/blog/announcements/welcome-redhat/">加入 Node.js 基金会成为白金会员</a>，未来将和IBM，Intel，Joyent，Microsoft 和 PayPal 等其它白金会员一起，为 Node.js 项目提供支持，包括财政、技术、以及高级战略指导等方面 &nbsp;。 &nbsp; &nbsp;<img src="http://static.oschina.net/uploads/logo/nodejs_IlxFc.png" style="height:auto;" /> 
	</p>
	<p>
		Node.js 支持红帽的技术，比如&nbsp;<a href="https://www.redhat.com/en/technologies/mobile/application-platform">Red Hat Mobile Application Platform</a>。红帽的高级总监Rich Sharples说，Node.js 是移动和物联网创建和部署新一代高敏感、可扩展应用程序的重要开发工具，红帽将和 Node.js 基金会和社区深入合作，提升这项技术在企业软件开发中的角色。
	</p>
</div>
<div class="NewsLinks" style="color:#333333;margin:0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<h3 style="font-family:inherit;color:inherit;font-size:24.5px;">
		相关链接
	</h3>
	<ul>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的详细介绍：<a href="http://www.oschina.net/p/nodejs">请点这里</a> 
		</li>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的下载地址：<a href="http://www.oschina.net/action/project/go?id=13342&p=download">请点这里</a> 
		</li>
	</ul>
	<p>
		想通过手机客户端（支持 Android、iPhone 和 Windows Phone）访问开源中国：<a href="http://www.oschina.net/app" target="_blank">请点这里</a> 
	</p>
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('88', '0', '<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。假如你的网站不能做到快速响应，又或你的App存在延迟，用户很快就会移情你的竞争对手。以下为大家总结10条有关性能提升的经验，以供参考：
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;text-align:center;background-color:#FFFFFF;">
	<img src="http://img.ptcms.csdn.net/article/201510/20/5625dfd8a2058.jpg" style="height:405px;width:512px;" />
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>1.&nbsp;&nbsp;采用反向代理服务器(Reverse Proxy Server)来对应用进行加速和保护</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	其作用主要在以下三方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		负载平衡&nbsp;– 运行在反向代理服务器上的负载平衡器会在不同的不服务器&nbsp; 间进行传输平衡。透过它，你可以进行无差别的服务器增添。
	</li>
	<li>
		存静态文件&nbsp;– 对于直接的文件请求，例如图片文件或代码文件，可以直接存储在反向代理服务器然后直接发送给用户，从而可以进行快速访问并为应用服务器进行减负使得程序性能得到提升。
	</li>
	<li>
		安全保护&nbsp;– 反向代理服务器可以进行高安全度配置和对威胁进行识别和监测。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>2.&nbsp;&nbsp;增添一个负载平衡器</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	为网站增添一个负载平衡器是一个相对简单的变更，但是它可以带来不错的性能和安全性提升。负载平衡器的作用在于在不同服务器间进行传输分发。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	负载平衡器的实施前提是有一个反向代理服务器，它在接收到Internet通信后把相关请求发送到其它服务器。平衡器的妙处在于它支持两个或以上的应用服务器，使用选择算法来分割服务器间的请求。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>3.&nbsp;&nbsp;缓存静态和动态内容</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	缓存技术的使用可使内容更快地展示给用户，其处理策略有：在需求发出时更快地处理内容，把内容存放在更快的设备上，或是使内容离用户更近。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>4.&nbsp;&nbsp;数据压缩</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	压缩技术是一个巨大的潜在性能加速器。其主要作用体现在对图片，视频或音频等文件，能够进行高效的压缩处理。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>5.&nbsp;&nbsp;优化SSL/TLS访问</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	尽管SSL/TLS变得越来越流行，但是它对于性能的影响也应得到重视。其对性能的影响主要体现在两个方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		每当新的连接开启，初始化握手都是无法避免的，即浏览器每次都需要使用HTTP/1.X建立服务器连接。
	</li>
	<li>
		存放于服务器上的加密数据会越来越大，加密后用户读取时也需要进行解码。
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">那么该如何进行处理呢？</span><br />
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		会话缓存—使用ssl_session_cache来直接缓存建立新SSL/TLS连接的参数
	</li>
	<li>
		会话ID化—把指定SSL/TLS的标识/ID存放起来，但要建立新连接时，就可以直接取用，从而免去重新建立通信的繁琐。
	</li>
	<li>
		OCSP stapling优化—通过抓取SSL/TLS认证信息来减免建立通信的时间。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>6.&nbsp;&nbsp;部署HTTP/2或SPDY</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	对于已经启用SSL/TLS的网站，一旦结合HTTP/2和SPDY将能实现性能上的强强联合；因为其结果是会让单一连接的建立仅需一次通信握手。SPDY和HTTP/2的主要特性是它们使用的是单一连接而不是多方连接。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>7.&nbsp;&nbsp;定期更新软件版本</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>8.&nbsp;&nbsp;优化Linux性能</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如对Linux进行以下配置或处理：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Backlog队列
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	如果你有一些将要停用的连接，可以考虑增加net.core.somaxconn。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		文件描述符
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	NGINX允许每个连接最多使用两个文件描述符。如果你的系统服务的是多个连接，你可能需要考虑增大sys.fs.file_max的值。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		瞬时端口
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	当作为一个代理使用时，NGINX会为每个upstream服务器创建临时的瞬时(ephemeral)端口。因此可以尝试加大net.ipv4.ip_local_port_range的值来增加可用端口数。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>9.&nbsp;&nbsp;优化Web服务器性能</b>
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		访问日志优化
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	在NGINX中，在access_log中加入buffer=size参数来实现日志的缓存写入；加入flush=time则可实现在某个时间间隔后进行缓存内容写入。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		缓存
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	启用缓存可使连接响应更快。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		客户端活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	活动连接可减少重连的次数，特别是启用SSL/TLS的情况下。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Upstream活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Upstream连接指的是连接到程序服务器，数据库服务器等的连接。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		限制资源的访问
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	采取合适的策略来限制资源访问可以提高性能和安全性。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行worker处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Worker处理模式就是请求驱动处理模式。NGINX使用了一个基于事件的模型和OS依赖机制来有效地对请求进行分发。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行socket分表
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Socket分表可以为每个worker处理创建一个socket监听器,当核心委派连接分到给监听器时，可以马上知道哪个处理是即将执行的，从而使处理流程变得简洁。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		线程池处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	任何计算机线程都有可能由于单个缓慢的操作而挂起。对于web服务器软件来说，磁盘访问是一个性能瓶颈，例如进行数据复制等操作。当使用线程池来处理时，可以把一些响应慢的操作单独地放入某个任务组里面，从而不会对其它操作造成影响。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>10.进行实时监控以快速解决问题和瓶颈</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	实施实时监控，可以全面掌握系统的运行情况，发现问题解决问题，甚至是找出造成性能瓶颈或运行缓慢的原因。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如可对如下的问题进行监控：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		服务器宕机
	</li>
	<li>
		连接访问丢失
	</li>
	<li>
		服务器缓存丢失严重
	</li>
	<li>
		服务器发送了错误的数据
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">原文来自：</span><a href="https://www.nginx.com/blog/10-tips-for-10x-application-performance/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" target="_blank">Nginx</a>', '', '0');
INSERT INTO `le_document_article` VALUES ('91', '0', '<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。假如你的网站不能做到快速响应，又或你的App存在延迟，用户很快就会移情你的竞争对手。以下为大家总结10条有关性能提升的经验，以供参考：</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;text-align:center;background-color:#FFFFFF;"><img src="http://img.ptcms.csdn.net/article/201510/20/5625dfd8a2058.jpg" data-ke-src="http://img.ptcms.csdn.net/article/201510/20/5625dfd8a2058.jpg" style="height:405px;width:512px;"> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>1.&nbsp;&nbsp;采用反向代理服务器(Reverse Proxy Server)来对应用进行加速和保护</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">其作用主要在以下三方面：</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>负载平衡&nbsp;– 运行在反向代理服务器上的负载平衡器会在不同的不服务器&nbsp; 间进行传输平衡。透过它，你可以进行无差别的服务器增添。</li><li>存静态文件&nbsp;– 对于直接的文件请求，例如图片文件或代码文件，可以直接存储在反向代理服务器然后直接发送给用户，从而可以进行快速访问并为应用服务器进行减负使得程序性能得到提升。</li><li>安全保护&nbsp;– 反向代理服务器可以进行高安全度配置和对威胁进行识别和监测。</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>2.&nbsp;&nbsp;增添一个负载平衡器</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">为网站增添一个负载平衡器是一个相对简单的变更，但是它可以带来不错的性能和安全性提升。负载平衡器的作用在于在不同服务器间进行传输分发。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">负载平衡器的实施前提是有一个反向代理服务器，它在接收到Internet通信后把相关请求发送到其它服务器。平衡器的妙处在于它支持两个或以上的应用服务器，使用选择算法来分割服务器间的请求。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>3.&nbsp;&nbsp;缓存静态和动态内容</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">缓存技术的使用可使内容更快地展示给用户，其处理策略有：在需求发出时更快地处理内容，把内容存放在更快的设备上，或是使内容离用户更近。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>4.&nbsp;&nbsp;数据压缩</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">压缩技术是一个巨大的潜在性能加速器。其主要作用体现在对图片，视频或音频等文件，能够进行高效的压缩处理。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>5.&nbsp;&nbsp;优化SSL/TLS访问</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">尽管SSL/TLS变得越来越流行，但是它对于性能的影响也应得到重视。其对性能的影响主要体现在两个方面：</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>每当新的连接开启，初始化握手都是无法避免的，即浏览器每次都需要使用HTTP/1.X建立服务器连接。</li><li>存放于服务器上的加密数据会越来越大，加密后用户读取时也需要进行解码。</li></ul><span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">那么该如何进行处理呢？</span><br> <ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>会话缓存—使用ssl_session_cache来直接缓存建立新SSL/TLS连接的参数</li><li>会话ID化—把指定SSL/TLS的标识/ID存放起来，但要建立新连接时，就可以直接取用，从而免去重新建立通信的繁琐。</li><li>OCSP stapling优化—通过抓取SSL/TLS认证信息来减免建立通信的时间。</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>6.&nbsp;&nbsp;部署HTTP/2或SPDY</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">对于已经启用SSL/TLS的网站，一旦结合HTTP/2和SPDY将能实现性能上的强强联合；因为其结果是会让单一连接的建立仅需一次通信握手。SPDY和HTTP/2的主要特性是它们使用的是单一连接而不是多方连接。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>7.&nbsp;&nbsp;定期更新软件版本</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>8.&nbsp;&nbsp;优化Linux性能</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">例如对Linux进行以下配置或处理：</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>Backlog队列</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">如果你有一些将要停用的连接，可以考虑增加net.core.somaxconn。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>文件描述符</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">NGINX允许每个连接最多使用两个文件描述符。如果你的系统服务的是多个连接，你可能需要考虑增大sys.fs.file_max的值。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>瞬时端口</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">当作为一个代理使用时，NGINX会为每个upstream服务器创建临时的瞬时(ephemeral)端口。因此可以尝试加大net.ipv4.ip_local_port_range的值来增加可用端口数。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>9.&nbsp;&nbsp;优化Web服务器性能</b> </p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>访问日志优化</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">在NGINX中，在access_log中加入buffer=size参数来实现日志的缓存写入；加入flush=time则可实现在某个时间间隔后进行缓存内容写入。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>缓存</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">启用缓存可使连接响应更快。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>客户端活动连接</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">活动连接可减少重连的次数，特别是启用SSL/TLS的情况下。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>Upstream活动连接</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">Upstream连接指的是连接到程序服务器，数据库服务器等的连接。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>限制资源的访问</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">采取合适的策略来限制资源访问可以提高性能和安全性。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>进行worker处理</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">Worker处理模式就是请求驱动处理模式。NGINX使用了一个基于事件的模型和OS依赖机制来有效地对请求进行分发。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>进行socket分表</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">Socket分表可以为每个worker处理创建一个socket监听器,当核心委派连接分到给监听器时，可以马上知道哪个处理是即将执行的，从而使处理流程变得简洁。</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>线程池处理</li></ul><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">任何计算机线程都有可能由于单个缓慢的操作而挂起。对于web服务器软件来说，磁盘访问是一个性能瓶颈，例如进行数据复制等操作。当使用线程池来处理时，可以把一些响应慢的操作单独地放入某个任务组里面，从而不会对其它操作造成影响。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><b>10.进行实时监控以快速解决问题和瓶颈</b> </p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">实施实时监控，可以全面掌握系统的运行情况，发现问题解决问题，甚至是找出造成性能瓶颈或运行缓慢的原因。</p><p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">例如可对如下的问题进行监控：</p><ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;"><li>服务器宕机</li><li>连接访问丢失</li><li>服务器缓存丢失严重</li><li>服务器发送了错误的数据</li></ul><span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">原文来自：</span><a href="https://www.nginx.com/blog/10-tips-for-10x-application-performance/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" data-ke-src="https://www.nginx.com/blog/10-tips-for-10x-application-performance/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" target="_blank">Nginx</a>', '', '0');
INSERT INTO `le_document_article` VALUES ('92', '0', '<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	随着网络的高速发展，网络性能的持续提高成为能否在芸芸App中脱颖而出的关键。高度联结的世界意味着用户对网络体验提出了更严苛的要求。假如你的网站不能做到快速响应，又或你的App存在延迟，用户很快就会移情你的竞争对手。以下为大家总结10条有关性能提升的经验，以供参考：
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;text-align:center;background-color:#FFFFFF;">
	<img src="http://img.ptcms.csdn.net/article/201510/20/5625dfd8a2058.jpg" style="height:405px;width:512px;" />
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>1.&nbsp;&nbsp;采用反向代理服务器(Reverse Proxy Server)来对应用进行加速和保护</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	其作用主要在以下三方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		负载平衡&nbsp;– 运行在反向代理服务器上的负载平衡器会在不同的不服务器&nbsp; 间进行传输平衡。透过它，你可以进行无差别的服务器增添。
	</li>
	<li>
		存静态文件&nbsp;– 对于直接的文件请求，例如图片文件或代码文件，可以直接存储在反向代理服务器然后直接发送给用户，从而可以进行快速访问并为应用服务器进行减负使得程序性能得到提升。
	</li>
	<li>
		安全保护&nbsp;– 反向代理服务器可以进行高安全度配置和对威胁进行识别和监测。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>2.&nbsp;&nbsp;增添一个负载平衡器</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	为网站增添一个负载平衡器是一个相对简单的变更，但是它可以带来不错的性能和安全性提升。负载平衡器的作用在于在不同服务器间进行传输分发。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	负载平衡器的实施前提是有一个反向代理服务器，它在接收到Internet通信后把相关请求发送到其它服务器。平衡器的妙处在于它支持两个或以上的应用服务器，使用选择算法来分割服务器间的请求。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>3.&nbsp;&nbsp;缓存静态和动态内容</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	缓存技术的使用可使内容更快地展示给用户，其处理策略有：在需求发出时更快地处理内容，把内容存放在更快的设备上，或是使内容离用户更近。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>4.&nbsp;&nbsp;数据压缩</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	压缩技术是一个巨大的潜在性能加速器。其主要作用体现在对图片，视频或音频等文件，能够进行高效的压缩处理。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>5.&nbsp;&nbsp;优化SSL/TLS访问</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	尽管SSL/TLS变得越来越流行，但是它对于性能的影响也应得到重视。其对性能的影响主要体现在两个方面：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		每当新的连接开启，初始化握手都是无法避免的，即浏览器每次都需要使用HTTP/1.X建立服务器连接。
	</li>
	<li>
		存放于服务器上的加密数据会越来越大，加密后用户读取时也需要进行解码。
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">那么该如何进行处理呢？</span><br />
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		会话缓存—使用ssl_session_cache来直接缓存建立新SSL/TLS连接的参数
	</li>
	<li>
		会话ID化—把指定SSL/TLS的标识/ID存放起来，但要建立新连接时，就可以直接取用，从而免去重新建立通信的繁琐。
	</li>
	<li>
		OCSP stapling优化—通过抓取SSL/TLS认证信息来减免建立通信的时间。
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>6.&nbsp;&nbsp;部署HTTP/2或SPDY</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	对于已经启用SSL/TLS的网站，一旦结合HTTP/2和SPDY将能实现性能上的强强联合；因为其结果是会让单一连接的建立仅需一次通信握手。SPDY和HTTP/2的主要特性是它们使用的是单一连接而不是多方连接。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>7.&nbsp;&nbsp;定期更新软件版本</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>8.&nbsp;&nbsp;优化Linux性能</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如对Linux进行以下配置或处理：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Backlog队列
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	如果你有一些将要停用的连接，可以考虑增加net.core.somaxconn。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		文件描述符
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	NGINX允许每个连接最多使用两个文件描述符。如果你的系统服务的是多个连接，你可能需要考虑增大sys.fs.file_max的值。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		瞬时端口
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	当作为一个代理使用时，NGINX会为每个upstream服务器创建临时的瞬时(ephemeral)端口。因此可以尝试加大net.ipv4.ip_local_port_range的值来增加可用端口数。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>9.&nbsp;&nbsp;优化Web服务器性能</b>
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		访问日志优化
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	在NGINX中，在access_log中加入buffer=size参数来实现日志的缓存写入；加入flush=time则可实现在某个时间间隔后进行缓存内容写入。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		缓存
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	启用缓存可使连接响应更快。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		客户端活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	活动连接可减少重连的次数，特别是启用SSL/TLS的情况下。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		Upstream活动连接
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Upstream连接指的是连接到程序服务器，数据库服务器等的连接。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		限制资源的访问
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	采取合适的策略来限制资源访问可以提高性能和安全性。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行worker处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Worker处理模式就是请求驱动处理模式。NGINX使用了一个基于事件的模型和OS依赖机制来有效地对请求进行分发。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		进行socket分表
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	Socket分表可以为每个worker处理创建一个socket监听器,当核心委派连接分到给监听器时，可以马上知道哪个处理是即将执行的，从而使处理流程变得简洁。
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		线程池处理
	</li>
</ul>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	任何计算机线程都有可能由于单个缓慢的操作而挂起。对于web服务器软件来说，磁盘访问是一个性能瓶颈，例如进行数据复制等操作。当使用线程池来处理时，可以把一些响应慢的操作单独地放入某个任务组里面，从而不会对其它操作造成影响。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<b>10.进行实时监控以快速解决问题和瓶颈</b>
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	实施实时监控，可以全面掌握系统的运行情况，发现问题解决问题，甚至是找出造成性能瓶颈或运行缓慢的原因。
</p>
<p style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	例如可对如下的问题进行监控：
</p>
<ul style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;background-color:#FFFFFF;">
	<li>
		服务器宕机
	</li>
	<li>
		连接访问丢失
	</li>
	<li>
		服务器缓存丢失严重
	</li>
	<li>
		服务器发送了错误的数据
	</li>
</ul>
<span style="color:#333333;font-family:Helvetica, Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;background-color:#FFFFFF;">原文来自：</span><a href="https://www.nginx.com/blog/10-tips-for-10x-application-performance/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" target="_blank">Nginx</a>', '', '0');
INSERT INTO `le_document_article` VALUES ('93', '0', '<h2 style="font-family:Arial, 'Microsoft YaHei', 'Hiragino Sans GB', 微软雅黑, Helvetica, sans-serif;font-weight:normal;color:#333333;font-size:24px;background-color:#FFFFFF;">
	大前端-HTML5-全栈时代开启谁决沉浮？
</h2>
<h2 style="font-family:Arial, 'Microsoft YaHei', 'Hiragino Sans GB', 微软雅黑, Helvetica, sans-serif;font-weight:normal;color:#333333;font-size:24px;background-color:#FFFFFF;">
	<a href="http://open.itcast.cn/front/3-297.html?1510wwtqun&amp;qq-pf-to=pcqq.group" target="_blank">http://open.itcast.cn/front/3-297.html?1510wwtqun&amp;qq-pf-to=pcqq.group</a><br />
</h2>
<span class="blank20" style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;line-height:15.2px;background-color:#FFFFFF;"></span><span style="color:#333333;font-family:微软雅黑, 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:16px;line-height:20px;background-color:#FFFFFF;"></span>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:14px;background-color:#FFFFFF;">
	课程介绍：
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	大前端时代IT技术发展方向是怎样的呢？HTML5时代给开发人员带来怎样的挑战和机遇呢？全栈时代给前端开发工程师带来怎样的革命呢？后端开发工程师在全栈时代如何把握自己的技术人生呢...
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	<br />
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	<span style="font-family:'Microsoft Yahei';font-size:16px;line-height:20.2667px;">开课时间：2015年10月13日20点</span>
</p>', '', '0');
INSERT INTO `le_document_article` VALUES ('94', '0', '<h2 style="font-family:Arial, 'Microsoft YaHei', 'Hiragino Sans GB', 微软雅黑, Helvetica, sans-serif;font-weight:normal;color:#333333;font-size:24px;background-color:#FFFFFF;">
	大前端-HTML5-全栈时代开启谁决沉浮？
</h2>
<h2 style="font-family:Arial, 'Microsoft YaHei', 'Hiragino Sans GB', 微软雅黑, Helvetica, sans-serif;font-weight:normal;color:#333333;font-size:24px;background-color:#FFFFFF;">
	<a href="http://open.itcast.cn/front/3-297.html?1510wwtqun&amp;qq-pf-to=pcqq.group" target="_blank">http://open.itcast.cn/front/3-297.html?1510wwtqun&amp;qq-pf-to=pcqq.group</a><br />
</h2>
<span class="blank20" style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;line-height:15.2px;background-color:#FFFFFF;"></span><span style="color:#333333;font-family:微软雅黑, 'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:16px;line-height:20px;background-color:#FFFFFF;"></span>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:14px;background-color:#FFFFFF;">
	课程介绍：
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	大前端时代IT技术发展方向是怎样的呢？HTML5时代给开发人员带来怎样的挑战和机遇呢？全栈时代给前端开发工程师带来怎样的革命呢？后端开发工程师在全栈时代如何把握自己的技术人生呢...
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	<br />
</p>
<p style="color:#333333;font-family:Arial, 宋体, 'Hiragino Sans GB', Georgia, serif;font-size:13.3333px;text-indent:2em;background-color:#FFFFFF;">
	<span style="font-family:'Microsoft Yahei';font-size:16px;line-height:20.2667px;">开课时间：2015年10月13日20点</span>
</p>', '', '0');
INSERT INTO `le_document_article` VALUES ('95', '0', '<div id="OSChina_News_66965" class="Body NewsContent TextContent" style="color:#333333;margin:10px 0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<p>
		红帽（Red Hat）公司近日<a target="_blank" href="https://nodejs.org/en/blog/announcements/welcome-redhat/">加入 Node.js 基金会成为白金会员</a>，未来将和IBM，Intel，Joyent，Microsoft 和 PayPal 等其它白金会员一起，为 Node.js 项目提供支持，包括财政、技术、以及高级战略指导等方面 &nbsp;。 &nbsp; &nbsp;<img src="http://static.oschina.net/uploads/logo/nodejs_IlxFc.png" style="height:auto;" />
	</p>
	<p>
		Node.js 支持红帽的技术，比如&nbsp;<a href="https://www.redhat.com/en/technologies/mobile/application-platform">Red Hat Mobile Application Platform</a>。红帽的高级总监Rich Sharples说，Node.js 是移动和物联网创建和部署新一代高敏感、可扩展应用程序的重要开发工具，红帽将和 Node.js 基金会和社区深入合作，提升这项技术在企业软件开发中的角色。
	</p>
</div>
<div class="NewsLinks" style="color:#333333;margin:0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<h3 style="font-family:inherit;color:inherit;font-size:24.5px;">
		相关链接
	</h3>
	<ul>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的详细介绍：<a href="http://www.oschina.net/p/nodejs">请点这里</a>
		</li>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的下载地址：<a href="http://www.oschina.net/action/project/go?id=13342&amp;p=download">请点这里</a>
		</li>
	</ul>
	<p>
		想通过手机客户端（支持 Android、iPhone 和 Windows Phone）访问开源中国：<a href="http://www.oschina.net/app" target="_blank">请点这里</a>
	</p>
</div>', '', '0');
INSERT INTO `le_document_article` VALUES ('96', '0', '<div id="OSChina_News_66965" class="Body NewsContent TextContent" style="color:#333333;margin:10px 0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<p>
		红帽（Red Hat）公司近日<a target="_blank" href="https://nodejs.org/en/blog/announcements/welcome-redhat/">加入 Node.js 基金会成为白金会员</a>，未来将和IBM，Intel，Joyent，Microsoft 和 PayPal 等其它白金会员一起，为 Node.js 项目提供支持，包括财政、技术、以及高级战略指导等方面 &nbsp;。 &nbsp; &nbsp;<img src="http://static.oschina.net/uploads/logo/nodejs_IlxFc.png" style="height:auto;" />
	</p>
	<p>
		Node.js 支持红帽的技术，比如&nbsp;<a href="https://www.redhat.com/en/technologies/mobile/application-platform">Red Hat Mobile Application Platform</a>。红帽的高级总监Rich Sharples说，Node.js 是移动和物联网创建和部署新一代高敏感、可扩展应用程序的重要开发工具，红帽将和 Node.js 基金会和社区深入合作，提升这项技术在企业软件开发中的角色。
	</p>
</div>
<div class="NewsLinks" style="color:#333333;margin:0px;padding:0px;font-size:10.5pt;font-family:'Microsoft YaHei', Verdana, sans-serif, SimSun;background-color:#FFFFFF;">
	<h3 style="font-family:inherit;color:inherit;font-size:24.5px;">
		相关链接
	</h3>
	<ul>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的详细介绍：<a href="http://www.oschina.net/p/nodejs">请点这里</a>
		</li>
		<li>
			<span class="pn" style="color:#AA0000;">Node.js</span>&nbsp;的下载地址：<a href="http://www.oschina.net/action/project/go?id=13342&amp;p=download">请点这里</a>
		</li>
	</ul>
	<p>
		想通过手机客户端（支持 Android、iPhone 和 Windows Phone）访问开源中国：<a href="http://www.oschina.net/app" target="_blank">请点这里</a>
	</p>
</div>', '', '0');

-- -----------------------------
-- Table structure for `le_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `le_document_download`;
CREATE TABLE `le_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `le_email`
-- -----------------------------
DROP TABLE IF EXISTS `le_email`;
CREATE TABLE `le_email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(50) NOT NULL COMMENT '主题',
  `body` varchar(1000) NOT NULL COMMENT '类容',
  `marks` tinyint(2) NOT NULL DEFAULT '0' COMMENT '删除标识0未删除，1已删除',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_email`
-- -----------------------------
INSERT INTO `le_email` VALUES ('1', 'test email', '我们来做个有检测，看看行还是不行！', '0', '1451959370', '1451975268');
INSERT INTO `le_email` VALUES ('2', 'test email2', 'testtest唐恬恬', '0', '1451960240', '1451960240');

-- -----------------------------
-- Table structure for `le_file`
-- -----------------------------
DROP TABLE IF EXISTS `le_file`;
CREATE TABLE `le_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `le_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `le_hooks`;
CREATE TABLE `le_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_hooks`
-- -----------------------------
INSERT INTO `le_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `le_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `le_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `le_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `le_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `le_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `le_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `le_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `le_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `le_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `le_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');

-- -----------------------------
-- Table structure for `le_member`
-- -----------------------------
DROP TABLE IF EXISTS `le_member`;
CREATE TABLE `le_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `email` varchar(25) NOT NULL DEFAULT '' COMMENT '邮箱',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `head_img` varchar(255) NOT NULL COMMENT '会员头像',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `le_member`
-- -----------------------------
INSERT INTO `le_member` VALUES ('1', 'admin', '10645760151@qq.com', '0', '0000-00-00', '', '680', '180', '0', '1442799808', '0', '1453343543', '1', '/Uploads/Picture/Photo/crop_1.jpg?t=1445585133');
INSERT INTO `le_member` VALUES ('33', 'test', 'xcsdyx123@126.com', '0', '0000-00-00', '', '20', '1', '0', '1444898266', '0', '1444898266', '1', '');
INSERT INTO `le_member` VALUES ('35', 'juzi', '1064576015@qq.com', '0', '0000-00-00', '', '110', '20', '0', '1445592580', '0', '1452927195', '1', '');
INSERT INTO `le_member` VALUES ('36', '容我静静', '734780463@qq.com', '0', '0000-00-00', '', '20', '1', '3232235635', '1444985365', '3232235635', '1444985365', '1', '');
INSERT INTO `le_member` VALUES ('55', 'apple', '12324@qq.com', '0', '0000-00-00', '', '10', '0', '0', '1448357547', '0', '0', '1', '');
INSERT INTO `le_member` VALUES ('56', 'email', 'xcsdyx123@126.com', '0', '0000-00-00', '', '10', '1', '0', '1451975225', '0', '0', '1', '');

-- -----------------------------
-- Table structure for `le_menu`
-- -----------------------------
DROP TABLE IF EXISTS `le_menu`;
CREATE TABLE `le_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_menu`
-- -----------------------------
INSERT INTO `le_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `le_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '0');
INSERT INTO `le_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('16', '用户', '0', '3', 'Users/index', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('17', '用户信息', '16', '0', 'Users/index', '0', '', '用户管理', '0', '0');
INSERT INTO `le_menu` VALUES ('18', '新增用户', '17', '0', 'Users/add', '0', '添加新用户', '', '0', '0');
INSERT INTO `le_menu` VALUES ('19', '用户行为', '16', '0', 'Users/action', '0', '', '行为管理', '0', '0');
INSERT INTO `le_menu` VALUES ('20', '新增用户行为', '19', '0', 'Users/addaction', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('21', '编辑用户行为', '19', '0', 'Users/editaction', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('22', '保存用户行为', '19', '0', 'Users/saveAction', '0', '"用户->用户行为"保存编辑和新增的用户行为', '', '0', '0');
INSERT INTO `le_menu` VALUES ('23', '变更行为状态', '19', '0', 'Users/setStatus', '0', '"用户->用户行为"中的启用,禁用和删除权限', '', '0', '0');
INSERT INTO `le_menu` VALUES ('24', '禁用会员', '19', '0', 'Users/changeStatus?method=forbidUser', '0', '"用户->用户信息"中的禁用', '', '0', '0');
INSERT INTO `le_menu` VALUES ('25', '启用会员', '19', '0', 'Users/changeStatus?method=resumeUser', '0', '"用户->用户信息"中的启用', '', '0', '0');
INSERT INTO `le_menu` VALUES ('26', '删除会员', '19', '0', 'Users/changeStatus?method=deleteUser', '0', '"用户->用户信息"中的删除', '', '0', '0');
INSERT INTO `le_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '0');
INSERT INTO `le_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '0');
INSERT INTO `le_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '0');
INSERT INTO `le_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '0');
INSERT INTO `le_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '0');
INSERT INTO `le_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '0');
INSERT INTO `le_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的"保存"按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '"后台 \ 用户 \ 用户信息"列表页的"授权"操作按钮,用于设置用户所属用户组', '', '0', '0');
INSERT INTO `le_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '"后台 \ 用户 \ 权限管理"列表页的"访问授权"操作按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '"后台 \ 用户 \ 权限管理"列表页的"成员授权"操作按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '"成员授权"列表页内的解除授权操作按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '"用户信息"列表页"授权"时的"保存"按钮和"成员授权"里右上角的"添加"按钮)', '', '0', '0');
INSERT INTO `le_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '"后台 \ 用户 \ 权限管理"列表页的"分类授权"操作按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '"分类授权"页面的"保存"按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '"后台 \ 用户 \ 权限管理"列表页的"模型授权"操作按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '"分类授权"页面的"保存"按钮', '', '0', '0');
INSERT INTO `le_menu` VALUES ('43', '扩展', '0', '6', 'Addons/index', '1', '', '', '1', '0');
INSERT INTO `le_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '0');
INSERT INTO `le_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '0');
INSERT INTO `le_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '0');
INSERT INTO `le_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '0');
INSERT INTO `le_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '0');
INSERT INTO `le_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '0');
INSERT INTO `le_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '0');
INSERT INTO `le_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '0');
INSERT INTO `le_menu` VALUES ('58', '模型管理', '68', '7', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `le_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('63', '属性管理', '68', '3', 'Attribute/index', '1', '网站属性配置。', '', '0', '0');
INSERT INTO `le_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('70', '配置管理', '68', '7', 'Config/index', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '0');
INSERT INTO `le_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '0');
INSERT INTO `le_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '0');
INSERT INTO `le_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '0');
INSERT INTO `le_menu` VALUES ('75', '菜单管理', '68', '8', 'Menu/index', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('76', '导航管理', '68', '9', 'Channel/index', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('80', '分类管理', '68', '6', 'Category/index', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '0');
INSERT INTO `le_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '0');
INSERT INTO `le_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '0');
INSERT INTO `le_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '0');
INSERT INTO `le_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '0');
INSERT INTO `le_menu` VALUES ('86', '备份数据库', '68', '4', 'Database/index?type=export', '0', '', '数据备份', '0', '0');
INSERT INTO `le_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '0');
INSERT INTO `le_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '0');
INSERT INTO `le_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '0');
INSERT INTO `le_menu` VALUES ('90', '还原数据库', '68', '5', 'Database/index?type=import', '0', '', '数据备份', '0', '0');
INSERT INTO `le_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '0');
INSERT INTO `le_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '0');
INSERT INTO `le_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0', '0');
INSERT INTO `le_menu` VALUES ('108', '修改密码', '16', '0', 'Users/updatePassword', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('109', '修改昵称', '16', '0', 'Users/updateNickname', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('124', 'testt1', '0', '0', '#1', '0', '', '', '0', '1');
INSERT INTO `le_menu` VALUES ('125', 'testchild', '124', '0', '#', '0', '', 'testt1', '0', '1');
INSERT INTO `le_menu` VALUES ('126', 'test2', '0', '0', '#', '0', 'rest', '', '0', '1');
INSERT INTO `le_menu` VALUES ('127', '即时通讯', '16', '0', 'users/chat', '0', '', '用户管理', '0', '0');
INSERT INTO `le_menu` VALUES ('128', '邮件类容', '0', '0', '#', '0', '', '邮件管理', '0', '1');
INSERT INTO `le_menu` VALUES ('129', '邮件内容', '16', '0', 'users/mail', '0', '', '邮件管理', '0', '0');
INSERT INTO `le_menu` VALUES ('130', '邮件发送', '129', '0', 'users/sendemail', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('131', '邮件编辑', '129', '0', 'users/emailedit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('132', '删除邮件', '129', '0', 'users/emaildel', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('133', '图片管理', '68', '2', 'Picture/index', '0', '', '系统设置', '0', '0');
INSERT INTO `le_menu` VALUES ('134', '图片添加', '133', '0', 'Picture/add', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('135', '图片类型修改', '133', '0', 'Picture/edit', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('136', '图片类型排序', '133', '0', 'Picture/sort', '0', '', '', '0', '0');
INSERT INTO `le_menu` VALUES ('137', '图片编辑', '133', '0', 'Picture/picedit', '0', '', '', '0', '0');

-- -----------------------------
-- Table structure for `le_model`
-- -----------------------------
DROP TABLE IF EXISTS `le_model`;
CREATE TABLE `le_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `le_model`
-- -----------------------------
INSERT INTO `le_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{"1":["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22"]}', '1:基础', '', '', '', '', 'id:编号
title:标题:article/index?cate_id=[category_id]&pid=[id]
type|get_document_type:类型
level:优先级
update_time|time_format:最后更新
status_text:状态
view:浏览
id:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `le_model` VALUES ('2', 'article', '文章', '1', '', '1', '{"1":["3","24","2","5"],"2":["9","13","19","10","12","16","17","26","20","14","11","25"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号
title:标题:article/edit?cate_id=[category_id]&id=[id]
content:内容', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `le_model` VALUES ('3', 'download', '下载', '1', '', '1', '{"1":["3","28","30","32","2","5","31"],"2":["13","10","27","9","12","16","17","19","11","20","14","29"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号
title:标题', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `le_picture`
-- -----------------------------
DROP TABLE IF EXISTS `le_picture`;
CREATE TABLE `le_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `type` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '图片类型',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '图片标题',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后更新时间',
  `marks` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_picture`
-- -----------------------------
INSERT INTO `le_picture` VALUES ('44', '/uploads/image/others/2016-01-14/20160114031230_98428.jpg', '', '4949305bf7a13bcdab14423113b56545', '09add6090faca9f64da6a13cc62ec8d398ecc91a', '0', 'test title', '1', '1452737550', '1452827228', '0');
INSERT INTO `le_picture` VALUES ('45', '/uploads/image/others/2016-01-14/20160114031230_92037.png', '', 'f021b685f385e5daf351ecc1f1c2899e', '9a59d32b0eec2143e9f8bfbb8b7362d271d27f18', '0', '', '1', '1452737550', '1452737550', '0');
INSERT INTO `le_picture` VALUES ('46', '/uploads/image/others/2016-01-14/20160114031230_23980.png', '', 'a85adacf67b8adb43ce5818505ca2461', '60c945958c9b8bc603c807e85e6c8ebc910328b0', '0', '', '1', '1452737550', '1452737550', '0');
INSERT INTO `le_picture` VALUES ('47', '/uploads/image/admin/2016-01-14/20160114031246_12425.jpg', '', '4949305bf7a13bcdab14423113b56545', '09add6090faca9f64da6a13cc62ec8d398ecc91a', '1', '', '1', '1452737566', '1452737566', '0');
INSERT INTO `le_picture` VALUES ('48', '/uploads/image/admin/2016-01-14/20160114031247_45288.png', '', 'f021b685f385e5daf351ecc1f1c2899e', '9a59d32b0eec2143e9f8bfbb8b7362d271d27f18', '1', '', '1', '1452737567', '1452737567', '0');
INSERT INTO `le_picture` VALUES ('49', '/uploads/image/admin/2016-01-14/20160114031247_42807.png', '', 'a85adacf67b8adb43ce5818505ca2461', '60c945958c9b8bc603c807e85e6c8ebc910328b0', '1', '', '1', '1452737567', '1452737567', '0');
INSERT INTO `le_picture` VALUES ('50', '/uploads/image/admin/2016-01-14/20160114031330_18563.jpg', '', '6fbacb4591ffb600b6bc6255a44f96be', 'e8c9a218889cd38755372677d66e64979885b5b5', '1', '', '1', '1452737609', '1452737609', '0');
INSERT INTO `le_picture` VALUES ('51', '/uploads/image/admin/2016-01-14/20160114031330_80177.jpg', '', '740364b6e50a46e77a2734293a2c285e', 'beff3bde92b0f753bccd71c03b34c7d00570919a', '1', '', '1', '1452737610', '1452737610', '0');
INSERT INTO `le_picture` VALUES ('52', '/uploads/image/admin/2016-01-14/20160114031330_55955.jpg', '', '73ce08a6f00e61457f6a94bce57ecac6', '5589caa158c35c6f6e097d9a853dc41bbd923b2e', '1', '', '1', '1452737610', '1452737610', '0');
INSERT INTO `le_picture` VALUES ('53', '/uploads/image/admin/2016-01-14/20160114031330_18714.jpg', '', 'f19c4381dafe742a2b76261bce355da3', 'ccb293bd412dfa81e361e75a19023b6351e175fd', '1', '', '1', '1452737610', '1452737610', '0');
INSERT INTO `le_picture` VALUES ('54', '/uploads/image/admin/2016-01-14/20160114031330_53049.jpg', '', '169315586cbda0da58cea5704fbefd80', '19cda78cbf4b24e808f29f235a70f1e7fdbae96d', '1', '', '1', '1452737610', '1452737610', '0');
INSERT INTO `le_picture` VALUES ('55', '/uploads/image/admin/2016-01-14/20160114031331_87286.jpg', '', '3568a4f5946658d260edd7de6ae6e8de', 'a8ae83e9938007000b617511af1a2c4ac935bff3', '1', '', '1', '1452737611', '1452737611', '0');
INSERT INTO `le_picture` VALUES ('56', '/uploads/image/admin/2016-01-14/20160114031331_26369.jpg', '', '285e535444947e137008c8a3a3f9b86a', 'f8517d1e5d06ec1492dbc9d8a3d44cd2adeabfbc', '1', '', '1', '1452737611', '1452737611', '0');
INSERT INTO `le_picture` VALUES ('57', '/uploads/image/admin/2016-01-14/20160114031331_16946.jpg', '', 'c95d1df027c39e802aa93373cb254568', '3dbc3f4c0ea1833ec4097e6b42620b2397152105', '1', '', '1', '1452737611', '1452737611', '0');
INSERT INTO `le_picture` VALUES ('58', '/uploads/image/others/2016-01-14/20160114034949_90875.jpg', '', '5ce46e67fddd2998536be9844715a86d', '40d726955e9200a430fbe35342d7f662ed180416', '0', '', '1', '1452739789', '1452739789', '0');
INSERT INTO `le_picture` VALUES ('59', '/uploads/image/others/2016-01-14/20160114034949_98437.jpg', '', 'ba19e5044ba689b1d8e7e2b3157f11ef', '98d9313b882d06c59c594b49b58366c509ba113a', '0', '', '1', '1452739789', '1452739789', '0');
INSERT INTO `le_picture` VALUES ('60', '/uploads/image/others/2016-01-14/20160114034949_77467.png', '', 'f01e96e597b529994057aa1f8c2556b3', '3f66e4f44be9ae079f5c61cc3eb27f1af7839589', '0', '', '1', '1452739789', '1452739789', '0');
INSERT INTO `le_picture` VALUES ('61', '/uploads/image/others/2016-01-14/20160114034950_79689.png', '', 'a05d370a217402f227c0906aa7794128', '62a3b087f581733651cab062b5212639ff9a85d8', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('62', '/uploads/image/others/2016-01-14/20160114034950_50479.png', '', 'b31e920b0ad8f822c17f4e84d0dee73d', '4b06c98e520f90dfef4772956e2a53e7b9ae3d58', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('63', '/uploads/image/others/2016-01-14/20160114034950_43318.png', '', 'f0ee90a17825d54b75dc384a70d401a6', '7bce73048fd5a20354212a9ca8856e0d155700d9', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('64', '/uploads/image/others/2016-01-14/20160114034950_15185.png', '', '388f69b71e9a64fdd3f41b1e69a37e24', '71a964c1c46d5778494a63bde04e7ea46017d113', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('65', '/uploads/image/others/2016-01-14/20160114034950_24131.jpg', '', '684a7c52a1216fa67a926fb56a563704', '38f7f10ca3f2bb568878154388841126d9395112', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('66', '/uploads/image/others/2016-01-14/20160114034950_75297.png', '', '34c149718ccee53ed8f7b445812fd30b', '68307556350c925979a14af95dccb0854ec2497f', '0', '', '1', '1452739790', '1452739790', '0');
INSERT INTO `le_picture` VALUES ('67', '/uploads/image/others/2016-01-14/20160114034951_76618.jpg', '', 'a564424115d082ad8c8d82dcaa43d1b5', '2ae1a740ed1331362b173ecb4900e1562a4bf0f0', '0', '', '1', '1452739791', '1452739791', '0');
INSERT INTO `le_picture` VALUES ('68', '/uploads/image/others/2016-01-14/20160114034951_50462.jpg', '', 'f897c124a10aba5f882129de8e77357f', 'd2fe135b47bdf8adedd09637846622612e9e26d8', '0', '', '1', '1452739791', '1452739791', '0');
INSERT INTO `le_picture` VALUES ('69', '/uploads/image/front/2016-01-14/20160114091522_15905.jpg', '', '7a2e529f9a0b7f3dd892f9570034b6db', '6d64923d0e334faf080a213d2828fe5975f2bad7', '2', '', '1', '1452759322', '1452759322', '0');
INSERT INTO `le_picture` VALUES ('70', '/uploads/image/front/2016-01-14/20160114091523_71630.jpg', '', '67a79a7a8b5111e28bf20b80329cf2e7', 'c9407eeaaf1a8db72b6ac8444ad4b94dc9f18fd7', '2', '', '1', '1452759323', '1452759323', '0');
INSERT INTO `le_picture` VALUES ('71', '/uploads/image/front/2016-01-14/20160114091523_80543.jpg', '', '532443dc65f6e06dd571d748eb8224f0', '597d312e3f66f8e9df0bbcb6897ab84e97c34465', '2', '', '1', '1452759323', '1452759323', '0');

-- -----------------------------
-- Table structure for `le_picture_type`
-- -----------------------------
DROP TABLE IF EXISTS `le_picture_type`;
CREATE TABLE `le_picture_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '表主键',
  `type_name` varchar(30) NOT NULL DEFAULT '' COMMENT '类型名称',
  `type_title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后更新时间',
  `marks` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `le_picture_type`
-- -----------------------------
INSERT INTO `le_picture_type` VALUES ('1', 'admin', '后台图片', '2', '1452501311', '1452501311', '0');
INSERT INTO `le_picture_type` VALUES ('2', 'front', '前台图片', '1', '1452502246', '1452650048', '0');

-- -----------------------------
-- Table structure for `le_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `le_ucenter_admin`;
CREATE TABLE `le_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `le_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `le_ucenter_app`;
CREATE TABLE `le_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `le_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `le_ucenter_member`;
CREATE TABLE `le_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `is_check` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否邮箱验证',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `le_ucenter_member`
-- -----------------------------
INSERT INTO `le_ucenter_member` VALUES ('1', 'admin', '2cdc554c6af27094df66d9a64c90a856', '10645760151@qq.com', '', '1446705468', '0', '1448068434', '0', '1446705468', '0', '1');
INSERT INTO `le_ucenter_member` VALUES ('35', 'juzi', '2cdc554c6af27094df66d9a64c90a856', '1064576015@qq.com', '', '1444984598', '0', '1447118880', '0', '1444984598', '0', '1');
INSERT INTO `le_ucenter_member` VALUES ('36', '容我静静', '3e516eb3faee6b0962c961c5c3320000', '734780463@qq.com', '', '1444985309', '3232235635', '1444985365', '3232235635', '1444985309', '0', '1');
INSERT INTO `le_ucenter_member` VALUES ('55', 'apple', '2cdc554c6af27094df66d9a64c90a856', '12324@qq.com', '', '1448357547', '0', '0', '0', '1448357547', '0', '-1');
INSERT INTO `le_ucenter_member` VALUES ('56', 'email', '2cdc554c6af27094df66d9a64c90a856', 'xcsdyx123@126.com', '', '1451975225', '0', '0', '0', '1451975225', '0', '1');

-- -----------------------------
-- Table structure for `le_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `le_ucenter_setting`;
CREATE TABLE `le_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `le_url`
-- -----------------------------
DROP TABLE IF EXISTS `le_url`;
CREATE TABLE `le_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `le_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `le_userdata`;
CREATE TABLE `le_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

